import random

czynnosc = ['Mam', 'Jem', 'Noszę', 'Robię', 'Oddam']
wedliny = ['polędwice', 'salami', 'szynkę', 'boczek', 'salceson']
miejsce = ('w ręce', 'na glowie', 'w domu', 'w samochodzie', 'na polanie')

czyn = random.randint(0, len(czynnosc) - 1)
miej = random.randint(0, len(miejsce) - 1)
wedlina = random.randint(0, len(wedliny) - 1)
print((czynnosc[czyn] + ' ' + str(czyn)) + ' ' + (miejsce[miej] + ' ' + str(miej)) + ' ' + (wedliny[wedlina] + ' ' + str(wedlina)))