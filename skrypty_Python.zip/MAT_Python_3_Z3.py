def dodaj_wartosc():
    nazwa = input(str("Podaj slowo: "))
    slow = input(str("Podaj tlumaczenie w jezyku angielskim: "))
    slownik[nazwa] = slow


def zmien_warosc():
    print(slownik.keys())
    edit = input("Wybierz wpis ktory chcesz edytowac: ")
    if edit in slownik:
        slownik[edit] = input("Nowe dane: ")


def usun_wartosc():
    print(slownik.keys())
    edit = input('Wybierz slowo ktore chcesz usunac: ')
    if edit in slownik:
        del slownik[edit]


def szukaj_wartosc():
    wpisz = input(str('Podaj szukany wyraz: '))
    if wpisz in slownik:
        print(wpisz, slownik[wpisz])
    else:
        print('\nBrak wyrazu w slowniku')


slownik = dict()


userAnswer = ""
while userAnswer != "Q":
    print(
        """
        -----------MENU----------
        1. Wyświetl słownik
        2. Dodaj
        3. Szukaj
        4. Usuń
        5. Zmień
        Q. Zakończ
        -------------------------""")
    userAnswer = input('Wprowadź wybraną opcję:\n')
    if userAnswer == '1':
        print(slownik)
    elif userAnswer == '2':
        print(dodaj_wartosc())
    elif userAnswer == '3':
        print(szukaj_wartosc())
    elif userAnswer == '4':
        print(usun_wartosc())
    elif userAnswer == '5':
        print(zmien_warosc())
    elif userAnswer == 'Q':
        print('Wyjscie z programu')
    else:
        print('\n Niepoprawny wybor pozycji z menu')