imieUzytkownika = input(str('Wpisz swoje imie: '))
nazwiskoUzytkownika = input(str('Wpisz swoje nazwisko: '))
if imieUzytkownika =='' and nazwiskoUzytkownika =='':
    print('Brak danych')
elif imieUzytkownika == '':
    print('Nie wypelniono pola imie')
elif nazwiskoUzytkownika == '':
    print('Nie wypelniono pola nazwisko')
else:
    print('HELLO ' + imieUzytkownika + ' ' + nazwiskoUzytkownika)