import random


def dodawanie(liczba1, liczba2):
    wynik = liczba1 + liczba2
    return wynik


def odejmowanie(liczba1, liczba2):
    wynik = liczba1 - liczba2
    return wynik


def mnozenie(liczba1, liczba2):
    wynik = liczba1 * liczba2
    return wynik


def dzielenie(liczba1, liczba2):
    wynik = ''
    if liczba2 != 0:
        wynik = liczba1 / liczba2
    else:
        print('Nie można dzielic przez 0')
    return wynik


pierwszy_znak = input('Podaj warosc liczbowa: ')

drugi_znak  = random.randint(0, 100)
print('Druga losowa liczba: ' + str(drugi_znak))

znaki = ["+", "-", "*", "/"]
typ_dzialania = znaki[random.randint(0, len(znaki) - 1)]
print('Typ dzialania: ' + typ_dzialania)

if pierwszy_znak == '':
    print('Nie podano wartosci liczbowej')
elif typ_dzialania == "+":
    wynik2 = dodawanie(int(pierwszy_znak), int(drugi_znak))
    print('Wynik: ' + str(wynik2))
elif typ_dzialania == "-":
    wynik2 = odejmowanie(int(pierwszy_znak), int(drugi_znak))
    print('Wynik: ' + str(wynik2))
elif typ_dzialania == "*":
    wynik2 = mnozenie(int(pierwszy_znak), int(drugi_znak))
    print('Wynik: ' + str(wynik2))
elif typ_dzialania == "/":
    wynik2 = dzielenie(int(pierwszy_znak), int(drugi_znak))
    print('Wynik: ' + str(wynik2))
